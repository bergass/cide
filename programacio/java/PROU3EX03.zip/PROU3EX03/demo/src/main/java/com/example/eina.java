package com.example; // defineix el paquet com.example

/**************************************/
/* Nom: Albert Bergas Consuegra 				*/
/* DNI/NIE: 45185379Q 			*/
/* Data: 13 / 12 / 2024 				*/
/* Exercici: PROU3EX03				*/
/**************************************/

public class eina { // classe base eina
    private double pes; // atribut del pes de l'eina
    private String material; // atribut del material de l'eina
    private String nom; // atribut del nom de l'eina

    public eina(double newPes, String newMaterial) { // constructor per inicialitzar el pes i el material
        this.pes = newPes; // assigna el pes
        this.material = newMaterial; // assigna el material
    }

    public void setPes(double newPes) { // metode per canviar el pes
        this.pes = newPes;
    }

    public double getPes() { // metode per obtenir el pes
        return this.pes;
    }

    public void setMaterial(String newMaterial) { // metode per canviar el material
        this.material = newMaterial;
    }

    public String getMaterial() { // metode per obtenir el material
        return this.material;
    }

    public void utilitzar() { // metode per executar una accio genèrica
        System.out.println("Utilitzant una eina generica"); // imprimeix
    }

    public String getNom() { // metode per obtenir el nom
        return this.nom;
    }
}
