package com.example; // defineix el paquet com.example

/**************************************/
/* Nom: Albert Bergas Consuegra 				*/
/* DNI/NIE: 45185379Q 			*/
/* Data: 13 / 12 / 2024 				*/
/* Exercici: PROU3EX03				*/
/**************************************/

public class destornillador extends eina { // classe destornillador que hereta de eina
    private String nom; // atribut especific del nom de destornillador

    public destornillador(double peso, String material) { // constructor per inicialitzar el pes i el material
        super(peso, material); // crida al constructor de la classe pare
        this.nom = "destornillador"; // assigna el nom especific
    }

    @Override // sobrescriu el metode utiitzaR() de eina per aquest
    public void utilitzar() { // sobrescriu el metode utilitzar
        System.out.println("Tornant cargols amb el destornillador");
    }

    @Override // sobrescriu el metode getnom() de eina per aquest
    public String getNom() { // metode per obtenir el nom
        return this.nom;
    }

    public void setNom(String newNom) { // metode per canviar el nom
        this.nom = newNom;
    }
}
