package com.example;  // defineix el paquet com.example

/**************************************/
/* Nom: Albert Bergas Consuegra 				*/
/* DNI/NIE: 45185379Q 			*/
/* Data: 13 / 12 / 2024 				*/
/* Exercici: PROU3EX03				*/
/**************************************/

public class Main {  // classe principal Main
    public static void main(String[] args) {  // metode principal que s'executa al iniciar el programa
        eina martell1 = new martell(5, "metall");  // crea un objecte martell amb pes 5 i material metall
        eina destornillador1 = new destornillador(1.5, "acer");  // crea un objecte destornillador amb pes 1.5 i material acer
        eina serra1 = new serra(2, "fusta");  // crea un objecte serra amb pes 2 i material fusta
        mostrarEina(martell1);  // mostra la informacio del martell
        mostrarEina(destornillador1);  // mostra la informacio del destornillador
        mostrarEina(serra1);  // mostra la informacio de la serra
    }

    public static void mostrarEina(eina miEina) {  // metode per mostrar la informacio d'una eina
        miEina.utilitzar();  // executa l'accio associada a l'eina
        System.out.println("Eina: " + miEina.getNom() + ", Pes: " + miEina.getPes() + " kg, Material: " + miEina.getMaterial() + "\n -----------------------");  // imprimeix la informacio de l'eina
    }
}
