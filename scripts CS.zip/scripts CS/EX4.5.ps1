$num = 1

while ($num -le 5) {
    Write-Host $num
    $num++
}