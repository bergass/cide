$num1 = 1
$num2 = 2
$sum = $num1 + $num2
$product = $num1 * $num2
$remainder = $num1 % $num2

Write-Host "Els numeros son $num1 i $num2"
Write-Host "La suma es $sum"
Write-Host "El producte es $product"
Write-Host "El rest es $remainder"