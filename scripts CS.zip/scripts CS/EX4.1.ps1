$name = Read-Host "Escriu el teu nom"
Write-Output "Hola $name com estas"