$num = 10

for ($i = 1; $i -le 10; $i++) {
    Write-Host $num
    $num--
}
